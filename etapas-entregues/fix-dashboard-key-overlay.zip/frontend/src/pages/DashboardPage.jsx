import React from 'react';
import Section from '../components/Section';
import StatCard from '../components/StatCard';
import Pill from '../components/Pill';
import {
  formatDateTime,
  formatList,
  formatMoney,
  formatNumber,
  formatPercent,
} from '../lib/format';
import {
  traduzirAcaoDecisao,
  traduzirClassificacaoSocial,
  traduzirChaveJob,
  traduzirNivelDrift,
  traduzirQualidade,
  traduzirRunbook,
  traduzirSeveridade,
  traduzirStatusGenerico,
} from '../lib/dashboard';

function emptyText(value, fallback = '—') {
  return value ?? fallback;
}

function safeArray(value) {
  return Array.isArray(value) ? value : [];
}

function readFeeBreakdown(portfolio = {}) {
  const baseFee =
    Number(
      portfolio?.feesPaidQuote ??
        portfolio?.feesQuote ??
        portfolio?.feesPaid ??
        portfolio?.quoteFee ??
        0,
    ) || 0;

  const bnbFee =
    Number(
      portfolio?.feesPaidBnb ??
        portfolio?.feesBnb ??
        portfolio?.bnbFeesPaid ??
        portfolio?.bnbFee ??
        0,
    ) || 0;

  return { baseFee, bnbFee };
}

function renderCard(card, index) {
  return (
    <StatCard
      key={card.key || card.id || `${card.label || 'card'}-${index}`}
      label={card.label}
      value={card.value}
      tone={card.tone}
      hint={card.hint}
    />
  );
}

export default function DashboardPage({ ctx }) {
  const {
    summaryCards = [],
    baseCurrency = 'USDT',
    currentPortfolio = {},
    currentDecisions = [],
    currentOrders = [],
    activeAlerts = [],
    latestReadiness,
    recentJobRuns = [],
    socialSummary,
    providerStatuses = [],
    recentTrainingRuns = [],
    trainingSummary,
  } = ctx || {};

  const positions = safeArray(currentPortfolio?.positions);
  const readinessChecks = safeArray(latestReadiness?.checks).slice(0, 4);
  const topClassifications = safeArray(socialSummary?.topClassifications).slice(0, 4);
  const trainingRunItems = safeArray(recentTrainingRuns).slice(0, 4);
  const qualityReport = trainingSummary?.qualityReport;
  const driftReport = trainingSummary?.driftReport;
  const activeRunbook = trainingSummary?.activeRunbook;
  const { baseFee, bnbFee } = readFeeBreakdown(currentPortfolio);

  const feeHint = (
    <>
      <div>Taxas {baseCurrency}: {formatMoney(baseFee, baseCurrency)}</div>
      <div>Taxas BNB: {formatNumber(bnbFee, 6)} BNB</div>
    </>
  );

  const normalizedSummaryCards = safeArray(summaryCards);
  const pnlCardIndex = normalizedSummaryCards.findIndex((card) => {
    const fingerprint = `${card?.key || ''} ${card?.id || ''} ${card?.label || ''}`.toLowerCase();
    return fingerprint.includes('pnl') || fingerprint.includes('realized');
  });

  const cardsToRender = (() => {
    const cards = normalizedSummaryCards.slice();
    const realizedPnlCard = {
      key: 'realized-pnl',
      label: 'PnL realizado',
      value: formatMoney(currentPortfolio?.realizedPnl || 0, baseCurrency),
      tone: Number(currentPortfolio?.realizedPnl || 0) >= 0 ? 'positive' : 'danger',
      hint: feeHint,
    };

    if (pnlCardIndex >= 0) {
      cards[pnlCardIndex] = {
        ...cards[pnlCardIndex],
        ...realizedPnlCard,
      };
      return cards;
    }

    return [...cards, realizedPnlCard];
  })();

  return (
    <div className="page-stack">
      <section className="stats-grid">
        {cardsToRender.map((card, index) => renderCard(card, index))}
      </section>

      <div className="dashboard-grid">
        <div className="page-stack">
          <Section
            title="Prontidão e alertas"
            subtitle="Situação operacional do backend, regras de proteção e filas automáticas."
          >
            <div className="page-stack">
              <div>
                <h4>Checklist de prontidão</h4>
                {readinessChecks.length ? (
                  <div className="list-stack">
                    {readinessChecks.map((item, index) => (
                      <article className="panel panel--soft" key={item.key || `${item.label || 'check'}-${index}`}>
                        <div className="panel__header-inline">
                          <strong>{item.label || item.key}</strong>
                          <Pill tone={item.status === 'ok' ? 'positive' : item.status === 'warn' ? 'warning' : 'danger'}>
                            {traduzirStatusGenerico(item.status)}
                          </Pill>
                        </div>
                        <div className="muted-text">{item.message || item.status || 'Sem detalhe adicional.'}</div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="muted-text">Nenhuma validação de prontidão foi registrada ainda.</div>
                )}
              </div>

              <div>
                <h4>Alertas recentes</h4>
                {activeAlerts.length ? (
                  <div className="list-stack">
                    {activeAlerts.slice(0, 6).map((alert, index) => (
                      <article className="panel panel--soft" key={alert.id || alert.alertKey || `${alert.title || 'alerta'}-${index}`}>
                        <div className="panel__header-inline">
                          <strong>{alert.title || alert.alertKey}</strong>
                          <Pill tone={alert.severity === 'critical' ? 'danger' : alert.severity === 'warning' ? 'warning' : 'info'}>
                            {traduzirSeveridade(alert.severity)}
                          </Pill>
                        </div>
                        <div className="muted-text">{alert.message || 'Sem mensagem adicional.'}</div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="muted-text">O backend não reportou alertas neste momento.</div>
                )}
              </div>
            </div>
          </Section>

          <Section
            title="Posições e ordens"
            subtitle="Visão rápida do que está aberto, do preço atual e do resultado já realizado."
          >
            <div className="page-stack">
              <div>
                <h4>Posições abertas</h4>
                {positions.length ? (
                  <div className="table-wrapper">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>Símbolo</th>
                          <th>Qtd</th>
                          <th>Entrada</th>
                          <th>Preço atual</th>
                          <th>Não realizado</th>
                        </tr>
                      </thead>
                      <tbody>
                        {positions.slice(0, 8).map((position, index) => (
                          <tr key={position.id || position.symbol || `position-${index}`}>
                            <td>{position.symbol}</td>
                            <td>{formatNumber(position.quantity, 6)}</td>
                            <td>{formatMoney(position.avgEntryPrice, baseCurrency)}</td>
                            <td>{formatMoney(position.lastPrice, baseCurrency)}</td>
                            <td className={(position.unrealizedPnl || 0) >= 0 ? 'text-positive' : 'text-danger'}>
                              {formatMoney(position.unrealizedPnl || 0, baseCurrency)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="muted-text">A carteira está zerada neste momento.</div>
                )}
              </div>

              <div>
                <h4>Ordens recentes</h4>
                {currentOrders.length ? (
                  <div className="list-stack">
                    {currentOrders.slice(0, 8).map((order, index) => (
                      <article className="panel panel--soft" key={order.id || `${order.symbol || 'order'}-${index}`}>
                        <div className="panel__header-inline">
                          <strong>
                            {order.symbol} • {traduzirAcaoDecisao(order.side)}
                          </strong>
                          <Pill tone={order.status === 'filled' ? 'positive' : order.status === 'rejected' ? 'danger' : 'info'}>
                            {traduzirStatusGenerico(order.status)}
                          </Pill>
                        </div>
                        <div className="muted-text">
                          {formatDateTime(order.createdAt)} • Preço: {formatMoney(order.price, baseCurrency)} • PnL:{' '}
                          {formatMoney(order.realizedPnl || 0, baseCurrency)}
                        </div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="muted-text">Ainda não há ordens registradas nesta base.</div>
                )}
              </div>
            </div>
          </Section>
        </div>

        <div className="page-stack">
          <Section
            title="IA, decisões e treinamento"
            subtitle="Acompanhamento do regime ativo, qualidade do treino e sinais publicados pela IA."
          >
            <div className="page-stack">
              <div>
                <h4>Decisões recentes</h4>
                {currentDecisions.length ? (
                  <div className="list-stack">
                    {currentDecisions.slice(0, 8).map((decision, index) => (
                      <article className="panel panel--soft" key={decision.id || `${decision.symbol || 'decision'}-${index}`}>
                        <div className="panel__header-inline">
                          <strong>
                            {decision.symbol} • {traduzirAcaoDecisao(decision.action)}
                          </strong>
                          <Pill tone={decision.action === 'BUY' ? 'positive' : decision.action === 'SELL' ? 'warning' : 'info'}>
                            {formatPercent(decision.confidence || 0)}
                          </Pill>
                        </div>
                        <div className="muted-text">{formatDateTime(decision.createdAt)} • Razão: {decision.reason || decision.summary || '—'}</div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="muted-text">A IA ainda não publicou sinais nesta base.</div>
                )}
              </div>

              <div>
                <h4>Treinamento</h4>
                <div className="list-stack">
                  <article className="panel panel--soft">
                    <div className="panel__header-inline">
                      <strong>Qualidade</strong>
                      <Pill tone={qualityReport?.status === 'good' ? 'positive' : qualityReport?.status === 'warning' ? 'warning' : 'info'}>
                        {traduzirQualidade(qualityReport?.status || 'unknown')}
                      </Pill>
                    </div>
                    <div className="muted-text">{emptyText(qualityReport?.message, 'Sem avaliação recente.')}</div>
                  </article>

                  <article className="panel panel--soft">
                    <div className="panel__header-inline">
                      <strong>Drift</strong>
                      <Pill tone={driftReport?.severity === 'high' ? 'danger' : driftReport?.severity === 'medium' ? 'warning' : 'info'}>
                        {traduzirNivelDrift(driftReport?.severity || 'low')}
                      </Pill>
                    </div>
                    <div className="muted-text">{emptyText(driftReport?.message, 'Sem drift relevante no momento.')}</div>
                  </article>

                  <article className="panel panel--soft">
                    <div className="panel__header-inline">
                      <strong>Runbook ativo</strong>
                      <Pill tone="info">{traduzirRunbook(activeRunbook?.key || activeRunbook || 'default')}</Pill>
                    </div>
                    <div className="muted-text">{emptyText(activeRunbook?.description, 'Nenhum runbook detalhado foi informado.')}</div>
                  </article>
                </div>
              </div>

              <div>
                <h4>Execuções recentes de treino</h4>
                {trainingRunItems.length ? (
                  <div className="list-stack">
                    {trainingRunItems.map((run, index) => (
                      <article className="panel panel--soft" key={run.id || `${run.createdAt || 'run'}-${index}`}>
                        <div className="panel__header-inline">
                          <strong>{formatDateTime(run.createdAt)}</strong>
                          <Pill tone={run.status === 'completed' ? 'positive' : run.status === 'failed' ? 'danger' : 'info'}>
                            {traduzirStatusGenerico(run.status)}
                          </Pill>
                        </div>
                        <div className="muted-text">{emptyText(run.summary || run.message, 'Sem resumo desta execução.')}</div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="muted-text">Ainda não há execuções recentes de treinamento.</div>
                )}
              </div>
            </div>
          </Section>

          <Section
            title="Radar social e automações"
            subtitle="Resumo das narrativas, da saúde dos providers e dos jobs automáticos mais recentes."
          >
            <div className="page-stack">
              <div>
                <h4>Classificações sociais</h4>
                {topClassifications.length ? (
                  <div className="pill-row">
                    {topClassifications.map((item, index) => (
                      <Pill key={`${item.classification || 'classification'}-${index}`} tone="info">
                        {traduzirClassificacaoSocial(item.classification)} • {item.count}
                      </Pill>
                    ))}
                  </div>
                ) : (
                  <div className="muted-text">Sem classificações recentes.</div>
                )}
              </div>

              <div>
                <h4>Providers</h4>
                {providerStatuses.length ? (
                  <div className="list-stack">
                    {providerStatuses.map((provider, index) => (
                      <article className="panel panel--soft" key={provider.id || provider.provider || `provider-${index}`}>
                        <div className="panel__header-inline">
                          <strong>{provider.provider}</strong>
                          <Pill tone={provider.status === 'healthy' ? 'positive' : provider.status === 'degraded' ? 'warning' : 'danger'}>
                            {traduzirStatusGenerico(provider.status)}
                          </Pill>
                        </div>
                        <div className="muted-text">
                          {provider.retryAfterSec ? `Retry em ${provider.retryAfterSec}s` : 'Sem janela de retry pendente.'}
                        </div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="muted-text">Nenhuma telemetria social foi recebida ainda.</div>
                )}
              </div>

              <div>
                <h4>Jobs recentes</h4>
                {recentJobRuns.length ? (
                  <div className="list-stack">
                    {recentJobRuns.slice(0, 5).map((job, index) => (
                      <article className="panel panel--soft" key={job.id || `${job.jobKey || 'job'}-${index}`}>
                        <div className="panel__header-inline">
                          <strong>{traduzirChaveJob(job.jobKey)}</strong>
                          <Pill tone={job.status === 'completed' ? 'positive' : job.status === 'failed' ? 'danger' : 'info'}>
                            {traduzirStatusGenerico(job.status)}
                          </Pill>
                        </div>
                        <div className="muted-text">{formatDateTime(job.createdAt)}</div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="muted-text">Ainda não há execuções automáticas registradas nesta base.</div>
                )}
              </div>
            </div>
          </Section>
        </div>
      </div>
    </div>
  );
}
