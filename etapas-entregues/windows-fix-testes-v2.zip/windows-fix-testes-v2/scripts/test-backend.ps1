param([string]$RepoPath)
if (-not $RepoPath -or -not $RepoPath.Trim()) { $RepoPath = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path) }
Set-Location (Join-Path $RepoPath 'backend')
npm test
