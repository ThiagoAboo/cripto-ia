param(
  [Parameter(Mandatory = $false)]
  [string]$RepoPath
)

$ErrorActionPreference = 'Stop'

if (-not $RepoPath -or -not $RepoPath.Trim()) {
  $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
  $RepoPath = Split-Path -Parent $scriptDir
}

$backendTests = Join-Path $RepoPath 'backend\tests'
$frontendTests = Join-Path $RepoPath 'frontend\src\lib'

Write-Host "RepoPath: $RepoPath"
Write-Host ''
Write-Host 'Backend:'
if (Test-Path $backendTests) {
  Get-ChildItem -Path $backendTests -Recurse -Filter '*.test.cjs' | Select-Object FullName
} else {
  Write-Host 'Pasta backend\tests não encontrada.'
}

Write-Host ''
Write-Host 'Frontend:'
if (Test-Path $frontendTests) {
  Get-ChildItem -Path $frontendTests -Recurse -Filter '*.test.js' | Select-Object FullName
} else {
  Write-Host 'Pasta frontend\src\lib não encontrada.'
}

Write-Host ''
Write-Host 'Versões:'
node -v
npm -v
