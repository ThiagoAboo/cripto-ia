param([string]$RepoPath)
if (-not $RepoPath -or -not $RepoPath.Trim()) { $RepoPath = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path) }

Write-Host '=== Backend ==='
& (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'test-backend.ps1') -RepoPath $RepoPath
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host ''
Write-Host '=== Frontend ==='
& (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'test-frontend.ps1') -RepoPath $RepoPath
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host ''
Write-Host 'Todos os testes executados.'
