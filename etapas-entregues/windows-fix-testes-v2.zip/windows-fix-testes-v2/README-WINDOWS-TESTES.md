# Correção de testes para Windows + VS Code

## O que foi corrigido
- remoção do erro no `apply-windows-test-fix.ps1` que impedia o `param(...)` de funcionar
- fallback automático para detectar o caminho do repositório
- scripts de `test` ajustados para usar diretórios, sem depender de glob no PowerShell

## Aplicar a correção
No PowerShell do VS Code:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
cd C:\caminho\para\windows-fix-testes-v2
.\scripts\apply-windows-test-fix.ps1 -RepoPath "D:\Projetos\cripto-ia"
```

Se você extrair esse pacote dentro da raiz do projeto, também pode rodar sem `-RepoPath`:

```powershell
.\scripts\apply-windows-test-fix.ps1
```

## Diagnóstico
```powershell
.\scripts\diagnostico-testes.ps1 -RepoPath "D:\Projetos\cripto-ia"
```

## Rodar testes
```powershell
.\scripts\test-all.ps1 -RepoPath "D:\Projetos\cripto-ia"
```
