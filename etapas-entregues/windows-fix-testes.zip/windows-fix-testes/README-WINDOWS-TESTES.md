# Correção Windows para os testes

Este pacote ajusta os scripts de teste do projeto para Windows + VS Code + PowerShell, evitando depender de glob no `node --test`.

## O que muda

- `backend/package.json`
  - de: `node --test tests/**/*.test.cjs`
  - para: `node --test tests`
- `frontend/package.json`
  - de: `node --test src/lib/*.test.js`
  - para: `node --test src/lib`

## Como aplicar

Abra o PowerShell no VS Code e rode:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\apply-windows-test-fix.ps1 -RepoPath "D:\Projetos\cripto-ia"
```

## Como testar

```powershell
.\scripts\diagnostico-testes.ps1 -RepoPath "D:\Projetos\cripto-ia"
.\scripts\test-backend.ps1 -RepoPath "D:\Projetos\cripto-ia"
.\scripts\test-frontend.ps1 -RepoPath "D:\Projetos\cripto-ia"
.\scripts\test-all.ps1 -RepoPath "D:\Projetos\cripto-ia"
```

## Observações

- O script de aplicação cria backup dos `package.json` antes de substituir.
- Se o PowerShell bloquear scripts, rode primeiro:
  `Set-ExecutionPolicy -Scope Process Bypass`
- Os testes precisam já existir no repositório, o que bate com o GitHub atual.
