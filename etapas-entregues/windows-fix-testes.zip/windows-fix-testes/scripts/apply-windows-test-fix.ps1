\
param(
  [Parameter(Mandatory = $true)]
  [string]$RepoPath
)

$ErrorActionPreference = "Stop"

function Copy-WithBackup {
  param(
    [Parameter(Mandatory = $true)][string]$Source,
    [Parameter(Mandatory = $true)][string]$Destination
  )

  if (-not (Test-Path $Destination)) {
    throw "Destino não encontrado: $Destination"
  }

  $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
  $backup = "$Destination.bak-$timestamp"
  Copy-Item $Destination $backup -Force
  Copy-Item $Source $Destination -Force
  Write-Host "Backup criado:" $backup
  Write-Host "Arquivo atualizado:" $Destination
}

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $packageRoot

$backendSource = Join-Path $root "backend\package.json"
$frontendSource = Join-Path $root "frontend\package.json"

$backendDest = Join-Path $RepoPath "backend\package.json"
$frontendDest = Join-Path $RepoPath "frontend\package.json"

if (-not (Test-Path $RepoPath)) {
  throw "RepoPath não encontrado: $RepoPath"
}

Copy-WithBackup -Source $backendSource -Destination $backendDest
Copy-WithBackup -Source $frontendSource -Destination $frontendDest

Write-Host ""
Write-Host "Correção aplicada com sucesso."
Write-Host "Agora rode:"
Write-Host "  .\scripts\diagnostico-testes.ps1 -RepoPath `"$RepoPath`""
Write-Host "  .\scripts\test-all.ps1 -RepoPath `"$RepoPath`""
