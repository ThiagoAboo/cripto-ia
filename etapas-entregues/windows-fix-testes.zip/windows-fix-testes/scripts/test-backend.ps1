\
param(
  [Parameter(Mandatory = $true)]
  [string]$RepoPath
)

$ErrorActionPreference = "Stop"
Push-Location (Join-Path $RepoPath "backend")
try {
  npm test
} finally {
  Pop-Location
}
