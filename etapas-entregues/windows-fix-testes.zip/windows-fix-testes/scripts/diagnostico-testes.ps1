\
param(
  [Parameter(Mandatory = $true)]
  [string]$RepoPath
)

$ErrorActionPreference = "Stop"

$backendTests = Join-Path $RepoPath "backend\tests"
$frontendLib = Join-Path $RepoPath "frontend\src\lib"

Write-Host "Node version:"
node -v
Write-Host ""

Write-Host "Backend test files:"
if (Test-Path $backendTests) {
  Get-ChildItem -Path $backendTests -Recurse -Filter *.test.cjs | Select-Object FullName
} else {
  Write-Host "Pasta não encontrada:" $backendTests
}
Write-Host ""

Write-Host "Frontend test files:"
if (Test-Path $frontendLib) {
  Get-ChildItem -Path $frontendLib -Recurse -Filter *.test.js | Select-Object FullName
} else {
  Write-Host "Pasta não encontrada:" $frontendLib
}
Write-Host ""

Write-Host "Scripts atuais do backend/package.json:"
Get-Content (Join-Path $RepoPath "backend\package.json")
Write-Host ""

Write-Host "Scripts atuais do frontend/package.json:"
Get-Content (Join-Path $RepoPath "frontend\package.json")
