\
param(
  [Parameter(Mandatory = $true)]
  [string]$RepoPath
)

$ErrorActionPreference = "Stop"
Push-Location (Join-Path $RepoPath "frontend")
try {
  npm test
} finally {
  Pop-Location
}
