\
param(
  [Parameter(Mandatory = $true)]
  [string]$RepoPath
)

$ErrorActionPreference = "Stop"
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

& (Join-Path $scriptRoot "diagnostico-testes.ps1") -RepoPath $RepoPath
Write-Host ""
& (Join-Path $scriptRoot "test-backend.ps1") -RepoPath $RepoPath
Write-Host ""
& (Join-Path $scriptRoot "test-frontend.ps1") -RepoPath $RepoPath
