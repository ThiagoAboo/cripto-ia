function renderScalar(value) {
  if (value == null || value === '') return '—';
  if (typeof value === 'string' || typeof value === 'number') return value;
  if (typeof value === 'boolean') return value ? 'Sim' : 'Não';
  return null;
}

function renderObject(value, className) {
  if (!value || typeof value !== 'object') return null;

  if (Array.isArray(value)) {
    return (
      <div className={className}>
        {value.map((item, index) => (
          <span key={`${className}-${index}`}>{renderContent(item, className)}</span>
        ))}
      </div>
    );
  }

  if (value.text != null) return renderContent(value.text, className);
  if (value.label != null) return renderContent(value.label, className);
  if (value.value != null && typeof value.value !== 'object') return renderContent(value.value, className);
  if (value.summary != null) return renderContent(value.summary, className);

  const knownGovernanceMode = renderScalar(value.mode);
  if (knownGovernanceMode) {
    const lines = [String(knownGovernanceMode).toUpperCase()];
    if (typeof value.liveReady === 'boolean') lines.push(value.liveReady ? 'Live pronto' : 'Live pendente');
    if (typeof value.useTestnet === 'boolean') lines.push(value.useTestnet ? 'Testnet ligado' : 'Testnet desligado');
    if (typeof value.supervised === 'boolean') lines.push(value.supervised ? 'Supervisionado' : 'Sem supervisão');
    if (typeof value.dryRun === 'boolean') lines.push(value.dryRun ? 'Dry-run' : 'Execução real');

    return (
      <div className={className}>
        {lines.map((line, index) => (
          <span key={`${className}-mode-${index}`}>{line}</span>
        ))}
      </div>
    );
  }

  const entries = Object.entries(value)
    .filter(([, item]) => item == null || ['string', 'number', 'boolean'].includes(typeof item))
    .slice(0, 4);

  if (entries.length) {
    return (
      <div className={className}>
        {entries.map(([key, item]) => (
          <span key={`${className}-${key}`}>{`${key}: ${renderScalar(item)}`}</span>
        ))}
      </div>
    );
  }

  return <span>{'—'}</span>;
}

function renderContent(value, className) {
  const scalar = renderScalar(value);
  if (scalar != null) return scalar;
  return renderObject(value, `${className} ${className}--stack`);
}

export default function StatCard({ label, value, hint, tone = 'default' }) {
  return (
    <article className={`stat-card stat-card--${tone}`}>
      <div className="stat-card__label">{label}</div>
      <div className="stat-card__value">{renderContent(value, 'stat-card__value-content')}</div>
      {hint ? <div className="stat-card__hint">{renderContent(hint, 'stat-card__hint-content')}</div> : null}
    </article>
  );
}
